#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, platform, sys, threading, webbrowser
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from typing import Any
from explorer.registry import discover

ROOT, WEB_ROOT, MAX_BODY = Path(__file__).resolve().parent, Path(__file__).resolve().parent / "web", 64 * 1024
EXAMPLES = discover()

def topologicpy_version() -> str:
    try:
        import topologicpy
        return str(getattr(topologicpy, "__version__", "unknown"))
    except Exception:
        return "not installed"

def plotly_version() -> str:
    try:
        import plotly
        return str(getattr(plotly, "__version__", "unknown"))
    except Exception:
        return "not installed"

class Handler(SimpleHTTPRequestHandler):
    server_version = "TopologicPyExplorer/0.5"
    def __init__(self, *args, **kwargs): super().__init__(*args, directory=str(WEB_ROOT), **kwargs)
    def log_message(self, fmt: str, *args: Any) -> None: print(f"[Explorer] {self.address_string()} - {fmt % args}")
    def _json(self, status: int, payload: Any) -> None:
        data = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        for key, value in (("Content-Type","application/json; charset=utf-8"),("Content-Length",str(len(data))),("Cache-Control","no-store"),("X-Content-Type-Options","nosniff")):
            self.send_header(key, value)
        self.end_headers(); self.wfile.write(data)
    def do_GET(self) -> None:
        if self.path == "/vendor/plotly.min.js":
            try:
                from plotly.offline import get_plotlyjs
                data = get_plotlyjs().encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/javascript; charset=utf-8")
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Cache-Control", "public, max-age=86400")
                self.end_headers()
                self.wfile.write(data)
            except Exception as exc:
                self._json(503, {"error": f"Plotly is unavailable: {exc}"})
            return
        if self.path == "/api/status":
            version = topologicpy_version()
            plotly = plotly_version()
            return self._json(200, {"ok": version != "not installed" and plotly != "not installed", "engine": "TopologicPy", "version": version, "plotly": plotly, "python": platform.python_version(), "executable": sys.executable})
        if self.path == "/api/examples":
            return self._json(200, [item.metadata for item in EXAMPLES.values()])
        if self.path == "/": self.path = "/index.html"
        super().do_GET()
    def do_POST(self) -> None:
        if self.path != "/api/execute": return self._json(404, {"error": "Unknown endpoint."})
        length = int(self.headers.get("Content-Length", "0"))
        if length <= 0 or length > MAX_BODY: return self._json(413, {"error": "Invalid request size."})
        try:
            request = json.loads(self.rfile.read(length))
            example_id, example = str(request.get("example", "")), None
            example = EXAMPLES.get(example_id)
            if example is None: return self._json(400, {"error": "This example is not enabled."})
            self._json(200, {"ok": True, "example": example_id, "result": example.execute(request.get("parameters") or {})})
        except (ValueError, TypeError) as exc: self._json(400, {"error": f"Invalid parameters: {exc}"})
        except Exception as exc: self._json(500, {"error": str(exc), "type": type(exc).__name__})

def main() -> None:
    parser = argparse.ArgumentParser(description="Run TopologicPy Explorer locally.")
    parser.add_argument("--host", default="127.0.0.1"); parser.add_argument("--port", type=int, default=8765); parser.add_argument("--no-browser", action="store_true")
    args = parser.parse_args(); server = ThreadingHTTPServer((args.host, args.port), Handler); url = f"http://{args.host}:{args.port}"
    print(f"\nTopologicPy Explorer 0.5\n  URL: {url}\n  Python: {sys.executable}\n  TopologicPy: {topologicpy_version()}\n  Plotly: {plotly_version()}\n")
    if not args.no_browser: threading.Timer(0.7, lambda: webbrowser.open(url)).start()
    try: server.serve_forever()
    except KeyboardInterrupt: print("\nStopping Explorer.")
    finally: server.server_close()

if __name__ == "__main__": main()
