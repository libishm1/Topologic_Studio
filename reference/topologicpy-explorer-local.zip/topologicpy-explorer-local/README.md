# TopologicPy Explorer — Local Preview 0.5

This package runs the Explorer and its TopologicPy compute service entirely on your computer. Models and results are not uploaded.

## Requirements

- Python 3.10 or newer
- A working TopologicPy installation in that Python environment
- The recommended PythonOCC backend
- Plotly in the same Python environment

For a new Conda environment:

```bash
conda create -n topologicpy -c conda-forge python=3.11 topologicpy
conda activate topologicpy
```

If Plotly is not already present:

```bash
python -m pip install plotly
```

## Start the Explorer

Activate the environment containing TopologicPy, open a terminal in this folder, and run:

```bash
python server.py
```

The Explorer should open automatically at:

```text
http://127.0.0.1:8765
```

If it does not open, copy that address into your browser. Press `Ctrl+C` in the terminal to stop it.

### Windows shortcut

After activating your Conda environment, double-click `run_windows.bat`.

### macOS or Linux

```bash
chmod +x run_mac_linux.sh
./run_mac_linux.sh
```

## Safety model

The browser cannot submit arbitrary Python. The local server exposes only auto-discovered example modules. This package contains two operations:

- `spaces-to-graph`: creates a cellular `CellComplex` and derives its adjacency `TGraph`.
- `shortest-path`: lets the user select two graph vertices and calls `TGraph.ShortestPath`.

Additional examples should be implemented as named, validated Python functions and added explicitly to that dictionary.

The server listens only on `127.0.0.1` by default, so other computers cannot connect to it. Do not use `--host 0.0.0.0` on an untrusted network.

## Interactive Plotly viewport

Each example builds independently styled model and graph traces, then combines them into one figure:

```python
model_data = Plotly.DataByTopology(model, ...)
graph_data = Plotly.DataByTGraph(tgraph, ...)
figure = Plotly.FigureByData(model_data + graph_data)
Plotly.SetCamera(figure, camera=[1.4, -1.6, 1.25], projection="perspective")
```

The returned figure is serialized and rendered with Plotly.js from the user's local Python Plotly installation. Orbit, pan, zoom, hover labels, camera controls and image export therefore behave like a normal TopologicPy Plotly figure.

The browser captures Plotly's current `scene.camera` after orbit, pan, or zoom, sends it with the next computation, and the backend reapplies its validated eye, center, up, and projection values. Changing parameters or selecting path vertices no longer resets the view.

## Example parameters

Each example declares its own controls in metadata. The browser generates sliders, numeric inputs and boolean checkboxes automatically and sends typed values to the example's `execute(parameters)` function.

## Adding examples

Examples are auto-discovered from `explorer/examples`. Each module owns its metadata, parameter validation, TopologicPy computation, metrics and scene result. The HTTP server does not need to be edited when an example is added.

See `ADDING_EXAMPLES.md` and `explorer/examples/_template.py.txt`.

## Interactive shortest path example

Select **Click to find the shortest path** from the example menu. Click one graph vertex to set the source and another to set the destination. The backend calls `TGraph.ShortestPath` using the stable clicked vertex indices and highlights the returned route in red.

## Troubleshooting

If the interface reports that TopologicPy is unavailable, verify the active interpreter:

```bash
python -c "import sys, topologicpy; print(sys.executable); print(topologicpy.__version__)"
```

If port 8765 is already in use:

```bash
python server.py --port 8766
```

Open `http://127.0.0.1:8766`.
