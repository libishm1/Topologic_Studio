from __future__ import annotations
import importlib
import pkgutil
from dataclasses import dataclass
from typing import Any, Callable
from explorer import examples

@dataclass(frozen=True)
class Example:
    id: str
    metadata: dict[str, Any]
    execute: Callable[[dict[str, Any]], dict[str, Any]]

def discover() -> dict[str, Example]:
    result: dict[str, Example] = {}
    for info in pkgutil.iter_modules(examples.__path__):
        if info.name.startswith("_"):
            continue
        module = importlib.import_module(f"{examples.__name__}.{info.name}")
        metadata, execute = getattr(module, "METADATA", None), getattr(module, "execute", None)
        if not isinstance(metadata, dict) or not callable(execute):
            continue
        example_id = str(metadata.get("id", "")).strip()
        if not example_id or example_id in result:
            raise RuntimeError(f"Invalid or duplicate example id in {info.name}.")
        result[example_id] = Example(example_id, metadata, execute)
    return result
