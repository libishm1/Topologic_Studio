"""Example modules discovered by the local Explorer."""
