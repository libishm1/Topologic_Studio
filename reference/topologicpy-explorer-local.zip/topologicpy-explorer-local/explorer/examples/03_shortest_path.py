from __future__ import annotations
import platform
import time
import json
import random
from typing import Any

CELL_ID_KEY = "cell_id"
FACE_ID_KEY = "face_id"

METADATA = {
    "id": "03_shortest-path",
    "title": "Click to find the shortest path",
    "category": "Graph analysis",
    "description": (
        "Click a graph vertex or model face to set the start, then click "
        "another to compute and highlight the shortest route."
    ),
    "frontend": "plotly",
    "interaction": "vertex-pair",
    "code": "model = CellComplex.Prism(\n    width=width, length=length, height=height,\n    uSides=columns, vSides=rows, wSides=layers\n)\ntgraph = TGraph.ByTopology(model, direct=direct,\n    viaSharedTopologies=viaSharedTopologies, ontology=False)\npath = TGraph.ShortestPath(tgraph, start, end,\n    mode='all', edgeKey='Length', useAStar=useAStar)",
    "parameters": [
        {
            "key": "columns",
            "label": "Columns",
            "type": "integer",
            "control": "slider",
            "min": 2,
            "max": 6,
            "step": 1,
            "default": 3,
        },
        {
            "key": "rows",
            "label": "Rows",
            "type": "integer",
            "control": "slider",
            "min": 2,
            "max": 6,
            "step": 1,
            "default": 3,
        },
        {
            "key": "layers",
            "label": "Layers",
            "type": "integer",
            "control": "slider",
            "min": 2,
            "max": 6,
            "step": 1,
            "default": 3,
        },
        {
            "key": "width",
            "label": "Width",
            "type": "number",
            "control": "slider",
            "min": 2,
            "max": 6,
            "step": 0.5,
            "default": 3,
        },
        {
            "key": "length",
            "label": "Length",
            "type": "number",
            "control": "slider",
            "min": 2,
            "max": 6,
            "step": 0.5,
            "default": 3,
        },
        {
            "key": "height",
            "label": "Height",
            "type": "number",
            "control": "slider",
            "min": 2,
            "max": 6,
            "step": 0.5,
            "default": 3,
        },
        {
            "key": "viaSharedTopologies",
            "label": "Via Shared Topologies",
            "type": "boolean",
            "control": "checkbox",
            "default": False
        },
        {
            "key": "toExteriorTopologies",
            "label": "To Exterior Topologies",
            "type": "boolean",
            "control": "checkbox",
            "default": False
        },
        {
            "key": "useAStar",
            "label": "Use A* Search",
            "type": "boolean",
            "control": "checkbox",
            "default": True
        },
    ],
    "views": ["model", "graph", "combined"],
}

def _version() -> str:
    import topologicpy
    return str(getattr(topologicpy, "__version__", "unknown"))

def execute(parameters: dict[str, Any]) -> dict[str, Any]:
    import plotly.graph_objects as go
    from topologicpy.CellComplex import CellComplex
    from topologicpy.Dictionary import Dictionary
    from topologicpy.Plotly import Plotly
    from topologicpy.TGraph import TGraph
    from topologicpy.Topology import Topology
    from topologicpy.Vertex import Vertex
    from topologicpy.Wire import Wire
    from explorer.plotly_scene import set_camera, set_scene_bounds

    columns = max(2, min(6, int(parameters.get("columns", 3))))
    rows = max(2, min(6, int(parameters.get("rows", 3))))
    layers = max(2, min(6, int(parameters.get("layers", 3))))
    width = max(2.0, min(6.0, float(parameters.get("width", 3))))
    length = max(2.0, min(6.0, float(parameters.get("length", 3))))
    height = max(2.0, min(6.0, float(parameters.get("height", 3))))
    viaSharedTopologies = bool(parameters.get("viaSharedTopologies", False))
    direct = not viaSharedTopologies
    toExteriorTopologies = bool(parameters.get("toExteriorTopologies", False))
    useAStar = bool(parameters.get("useAStar", True))
    view = str(parameters.get("_view", "combined")).lower()
    start_token = _optional_index(parameters.get("_startIndex"))
    end_token = _optional_index(parameters.get("_endIndex"))
    started = time.perf_counter()

    model = CellComplex.Prism(width=width, length=length, height=height,
        uSides=columns, vSides=rows, wSides=layers, placement="center", tolerance=0.0001)
    if model is None:
        raise RuntimeError("CellComplex.Prism returned None.")

    # Cell IDs must exist before TGraph.ByTopology so each cell's graph vertex
    # inherits the same stable identifier. Face IDs identify exact Plotly
    # face-click targets and are resolved by the backend after each click.
    cells = Topology.Cells(model) or []
    _assign_cell_ids(cells, Topology)
    faces = Topology.Faces(model) or []
    _assign_face_ids(faces, Topology)

    tgraph = TGraph.ByTopology(
        model, direct=direct, viaSharedTopologies=viaSharedTopologies,
        toExteriorTopologies=toExteriorTopologies, ontology=False, silent=True
    )
    if tgraph is None:
        raise RuntimeError("TGraph.ByTopology returned None.")

    records = TGraph.Vertices(tgraph, copy=False, asTopologic=False) or []
    topologic_vertices = TGraph.Vertices(tgraph, copy=False, asTopologic=True) or []
    graph_edges = TGraph.Edges(tgraph, asTopologic=False) or []
    stable_indices = [int(record.get("index", i)) for i, record in enumerate(records)]

    graph_index_by_cell_id = _graph_indices_by_cell_id(records)
    start_index = _resolve_selection_token(
        start_token,
        stable_indices,
        faces,
        model,
        graph_index_by_cell_id,
        Topology,
        Dictionary,
    )
    end_index = _resolve_selection_token(
        end_token,
        stable_indices,
        faces,
        model,
        graph_index_by_cell_id,
        Topology,
        Dictionary,
    )

    # Each topological face is rendered independently. This avoids inferring
    # face identity from hover text, tessellation indices, or trace ordering.
    model_faces = _clickable_model_face_data(
        Plotly, faces, Topology, Dictionary
    )
    model_edges = Plotly.DataByTopology(
        model, showVertices=False, showEdges=True, edgeWidth=1,
        edgeColor="#7d897f", showFaces=False, showEdgeLegend=True,
        edgeLegendLabel="CellComplex edges",
        silent=True,
    ) or []
    model_data = model_faces + model_edges
    graph_data = Plotly.DataByTGraph(
        tgraph, showVertices=False, showEdges=True, edgeWidth=3,
        edgeColor="#557164", showEdgeLegend=True,
        edgeLegendLabel="Adjacency", silent=True,
    ) or []

    path_indices, path_cost = [], None
    path_data = []
    if start_index is not None and end_index is not None and start_index != end_index:
        path_result = TGraph.ShortestPath(
            tgraph, start_index, end_index, mode="all", edgeKey="Length",
            useAStar=useAStar, returnCost=True, silent=True,
        )
        if isinstance(path_result, tuple):
            path_indices, path_cost = list(path_result[0] or []), float(path_result[1])
        elif isinstance(path_result, list):
            path_indices = path_result
        if len(path_indices) >= 2:
            vertex_by_index = {
                stable_indices[i]: topologic_vertices[i]
                for i in range(min(len(stable_indices), len(topologic_vertices)))
            }
            path_vertices = [
                vertex_by_index[index]
                for index in path_indices
                if index in vertex_by_index
            ]
            path_wire = Wire.ByVertices(path_vertices, close=False, silent=True)
            path_data = Plotly.DataByTopology(
                path_wire, showVertices=False, showFaces=False, showEdges=True,
                edgeWidth=12, edgeColor="#e5483f", showEdgeLegend=True,
                edgeLegendLabel="Shortest path", silent=True,
            ) or []

    coordinates = [
        Vertex.Coordinates(vertex, mantissa=6)
        for vertex in topologic_vertices
    ]
    colors = [
        "#2f7bf6" if index == start_index else
        "#e5483f" if index == end_index else
        "#173c2b"
        for index in stable_indices
    ]
    sizes = [
        20 if index in (start_index, end_index) else 12
        for index in stable_indices
    ]
    vertex_data = [go.Scatter3d(
        x=[point[0] for point in coordinates],
        y=[point[1] for point in coordinates],
        z=[point[2] for point in coordinates],
        mode="markers",
        name="Element centroids",
        marker={
            "size": sizes,
            "color": colors,
            "line": {"color": "#ffffff", "width": 1},
        },
        customdata=[{"vertexIndex": index} for index in stable_indices],
        hovertemplate="Vertex %{customdata.vertexIndex}<extra>Click to select</extra>",
        showlegend=True,
    )]

    if view == "model":
        data = model_data
    elif view == "graph":
        data = graph_data + path_data + vertex_data
    else:
        data = model_data + graph_data + path_data + vertex_data

    figure = Plotly.FigureByData(
        data, width=950, height=620, backgroundColor="#f5f7f3",
        xAxis=False, yAxis=False, zAxis=False,
    )
    if figure is None:
        raise RuntimeError("Plotly.FigureByData could not create the figure.")
    set_scene_bounds(figure, model)
    set_camera(figure, parameters.get("_camera"), [1.4, -1.6, 1.25])
    figure.update_layout(clickmode="event+select")

    return {
        "parameters": {"columns": columns,
                       "rows": rows,
                       "layers": layers,
                       "width": width,
                       "length": length,
                       "height": height,
                       "viaSharedTopologies": viaSharedTopologies,
                       "toExteriorTopologies": toExteriorTopologies,
                       "useAStar": useAStar
                       },
        "selection": {"startIndex": start_index, "endIndex": end_index},
        "metrics": {"cells": len(cells), "graphVertices": len(records),
            "graphEdges": len(graph_edges), "pathVertices": len(path_indices),
            "pathCost": path_cost,
            "elapsedMs": round((time.perf_counter() - started) * 1000, 2)},
        "plotly": json.loads(figure.to_json()),
        "engine": {"name": "TopologicPy", "version": _version(), "python": platform.python_version()},
        "message": "Click a start vertex or model face." if start_index is None else
            "Click a destination vertex or model face." if end_index is None else
            "Choose a different destination." if start_index == end_index else
            "Shortest path computed locally.",
    }

def _optional_index(value):
    try:
        return int(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def _resolve_selection_token(
    token,
    stable_indices,
    faces,
    model,
    graph_index_by_cell_id,
    Topology,
    Dictionary,
):
    """Resolve one graph-vertex index or one exact topological face token."""
    if token is None:
        return None

    valid_indices = set(stable_indices)
    if token in valid_indices:
        return token
    if token >= 0:
        return None

    # The current Explorer transports clicks through the integer vertexIndex
    # field. Negative values are reserved for exact face IDs.
    face_id = -token - 1
    face = _face_by_id(faces, face_id, Topology, Dictionary)
    if face is None:
        return None

    incident_cells = Topology.SuperTopologies(
        face, model, topologyType="Cell", silent=True
    ) or []
    candidates = []
    for cell in incident_cells:
        cell_id = _topology_cell_id(cell, Topology, Dictionary)
        graph_index = graph_index_by_cell_id.get(str(cell_id))
        if graph_index in valid_indices:
            candidates.append(graph_index)

    candidates = sorted(set(candidates))
    if not candidates:
        return None

    # Internal faces have two incident cells. Make an arbitrary choice that is
    # stable across camera updates and view changes.
    return random.Random(face_id).choice(candidates)


def _assign_cell_ids(cells, Topology):
    """Assign deterministic IDs before TGraph.ByTopology copies dictionaries."""
    for position, cell in enumerate(cells):
        tagged_cell = Topology.SetDictionary(
            cell, {CELL_ID_KEY: f"cell_{position:06d}"}, silent=True
        )
        if tagged_cell is not None:
            cells[position] = tagged_cell


def _assign_face_ids(faces, Topology):
    """Give every exact model face a stable ID for Plotly click payloads."""
    for position, face in enumerate(faces):
        tagged_face = Topology.SetDictionary(
            face, {FACE_ID_KEY: position}, silent=True
        )
        if tagged_face is not None:
            faces[position] = tagged_face


def _graph_indices_by_cell_id(records):
    """Index TGraph vertex records by the cell IDs they inherited."""
    result = {}
    for position, record in enumerate(records):
        dictionary = record.get("dictionary") or {}
        cell_id = dictionary.get(CELL_ID_KEY)
        if cell_id is not None:
            result[str(cell_id)] = int(record.get("index", position))
    return result


def _topology_cell_id(cell, Topology, Dictionary):
    dictionary = Topology.Dictionary(cell, silent=True)
    return Dictionary.ValueAtKey(
        dictionary, CELL_ID_KEY, defaultValue=None, silent=True
    )


def _topology_face_id(face, Topology, Dictionary):
    dictionary = Topology.Dictionary(face, silent=True)
    return Dictionary.ValueAtKey(
        dictionary, FACE_ID_KEY, defaultValue=None, silent=True
    )


def _face_by_id(faces, face_id, Topology, Dictionary):
    for face in faces:
        value = _topology_face_id(face, Topology, Dictionary)
        try:
            if int(value) == face_id:
                return face
        except (TypeError, ValueError):
            continue
    return None


def _clickable_model_face_data(Plotly, faces, Topology, Dictionary):
    """Render one trace per exact face and attach its backend selection token."""
    data = []
    first_face = True
    for face in faces:
        face_id = _topology_face_id(face, Topology, Dictionary)
        try:
            face_id = int(face_id)
        except (TypeError, ValueError):
            continue

        traces = Plotly.DataByTopology(
            face,
            showVertices=False,
            showEdges=False,
            showFaces=True,
            faceColor="#d9f45a",
            faceOpacity=0.2,
            showFaceLegend=first_face,
            faceLegendLabel="CellComplex",
            silent=True,
        ) or []
        token = -(face_id + 1)
        tagged = False
        for trace in traces:
            if str(getattr(trace, "type", "")).lower() != "mesh3d":
                continue
            count = len(getattr(trace, "x", None) or [])
            trace.customdata = [
                {
                    "vertexIndex": token,
                    "faceId": face_id,
                    "sourceType": "face",
                }
                for _ in range(count)
            ]
            trace.hovertemplate = (
                "Face %{customdata.faceId}"
                "<extra>Click to select route endpoint</extra>"
            )
            tagged = True
        data.extend(traces)
        if tagged:
            first_face = False
    return data
