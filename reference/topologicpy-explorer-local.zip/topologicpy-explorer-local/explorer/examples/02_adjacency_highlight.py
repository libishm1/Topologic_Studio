from __future__ import annotations
import platform
import time
import json
import random
from typing import Any

CELL_ID_KEY = "cell_id"
FACE_ID_KEY = "face_id"

METADATA = {
    "id": "02_adjacency-highlight",
    "title": "Explore direct adjacency",
    "category": "Graph analysis",
    "description": (
        "Click a graph vertex or model face to highlight the corresponding "
        "cell and its directly adjacent graph vertices and cells."
    ),
    "frontend": "plotly",
    # The current Explorer attaches Plotly click events through this hook. This
    # example treats the most recently clicked endpoint as one selection.
    "interaction": "vertex-pair",
    "code": (
        "tgraph = TGraph.ByTopology(model, direct=True,\n"
        "    directApertures=False, viaSharedTopologies=False,\n"
        "    viaSharedApertures=False, toExteriorTopologies=False,\n"
        "    toExteriorApertures=False, toContents=False,\n"
        "    toOutposts=False, ontology=False)\n"
        "# Each cell_id is inherited by its graph vertex.\n"
        "adjacent = TGraph.AdjacentIndices(tgraph, selected, mode='all')"
    ),
    "parameters": [
        {
            "key": "columns",
            "label": "Columns",
            "type": "integer",
            "control": "slider",
            "min": 2,
            "max": 6,
            "step": 1,
            "default": 3,
        },
        {
            "key": "rows",
            "label": "Rows",
            "type": "integer",
            "control": "slider",
            "min": 2,
            "max": 6,
            "step": 1,
            "default": 3,
        },
        {
            "key": "layers",
            "label": "Layers",
            "type": "integer",
            "control": "slider",
            "min": 2,
            "max": 6,
            "step": 1,
            "default": 3,
        },
        {
            "key": "width",
            "label": "Width",
            "type": "number",
            "control": "slider",
            "min": 2,
            "max": 6,
            "step": 0.5,
            "default": 3,
        },
        {
            "key": "length",
            "label": "Length",
            "type": "number",
            "control": "slider",
            "min": 2,
            "max": 6,
            "step": 0.5,
            "default": 3,
        },
        {
            "key": "height",
            "label": "Height",
            "type": "number",
            "control": "slider",
            "min": 2,
            "max": 6,
            "step": 0.5,
            "default": 3,
        },
    ],
    "views": ["model", "graph", "combined"],
}

def _version() -> str:
    import topologicpy
    return str(getattr(topologicpy, "__version__", "unknown"))

def execute(parameters: dict[str, Any]) -> dict[str, Any]:
    import plotly.graph_objects as go
    from topologicpy.CellComplex import CellComplex
    from topologicpy.Dictionary import Dictionary
    from topologicpy.Plotly import Plotly
    from topologicpy.TGraph import TGraph
    from topologicpy.Topology import Topology
    from topologicpy.Vertex import Vertex

    from explorer.plotly_scene import set_camera, set_scene_bounds

    columns = max(2, min(6, int(parameters.get("columns", 3))))
    rows = max(2, min(6, int(parameters.get("rows", 3))))
    layers = max(2, min(6, int(parameters.get("layers", 3))))
    width = max(2.0, min(6.0, float(parameters.get("width", 3))))
    length = max(2.0, min(6.0, float(parameters.get("length", 3))))
    height = max(2.0, min(6.0, float(parameters.get("height", 3))))
    view = str(parameters.get("_view", "combined")).lower()
    if view not in METADATA["views"]:
        view = "combined"

    started = time.perf_counter()
    model = CellComplex.Prism(
        width=width,
        length=length,
        height=height,
        uSides=columns,
        vSides=rows,
        wSides=layers,
        placement="center",
        tolerance=0.0001,
    )
    if model is None:
        raise RuntimeError("CellComplex.Prism returned None.")

    cells = Topology.Cells(model) or []
    _assign_cell_ids(cells, Topology)
    faces = Topology.Faces(model) or []
    _assign_face_ids(faces, Topology)

    # Direct cell-to-cell adjacency only. All other relationship options are
    # deliberately disabled.
    tgraph = TGraph.ByTopology(
        model,
        direct=True,
        directApertures=False,
        viaSharedTopologies=False,
        viaSharedApertures=False,
        toExteriorTopologies=False,
        toExteriorApertures=False,
        toContents=False,
        toOutposts=False,
        useInternalVertex=False,
        storeBREP=False,
        ontology=False,
        silent=True,
    )
    if tgraph is None:
        raise RuntimeError("TGraph.ByTopology returned None.")

    records = TGraph.Vertices(tgraph, copy=False, asTopologic=False) or []
    graph_vertices = TGraph.Vertices(tgraph, copy=False, asTopologic=True) or []
    graph_edges = TGraph.Edges(tgraph, asTopologic=False) or []
    stable_indices = [int(record.get("index", i)) for i, record in enumerate(records)]

    graph_index_by_cell_id = _graph_indices_by_cell_id(records)
    selected_index = _resolve_clicked_selection(
        parameters,
        stable_indices,
        faces,
        model,
        graph_index_by_cell_id,
        Topology,
        Dictionary,
    )
    adjacent_indices = (
        TGraph.AdjacentIndices(tgraph, selected_index, mode="all") or []
        if selected_index is not None
        else []
    )
    adjacent_indices = sorted(
        {int(index) for index in adjacent_indices if int(index) in stable_indices}
    )

    graph_coordinates = [
        Vertex.Coordinates(vertex, mantissa=6) for vertex in graph_vertices
    ]
    cell_by_index = _cells_by_graph_index(
        cells, graph_index_by_cell_id, Topology, Dictionary
    )

    # Render faces independently so every Mesh3d trace has one unambiguous
    # topological face ID. Plotly may tessellate a face into several triangles,
    # but every resulting point in that trace carries the same face token.
    model_faces = _clickable_model_face_data(
        Plotly, faces, Topology, Dictionary
    )
    model_edges = Plotly.DataByTopology(
        model,
        showVertices=False,
        showEdges=True,
        edgeWidth=1,
        edgeColor="#7d897f",
        showFaces=False,
        showEdgeLegend=True,
        edgeLegendLabel="CellComplex edges",
        silent=True,
    ) or []

    graph_data = Plotly.DataByTGraph(
        tgraph,
        showVertices=False,
        showEdges=True,
        edgeWidth=3,
        edgeColor="#557164",
        showEdgeLegend=True,
        edgeLegendLabel="Adjacency",
        silent=True,
    ) or []
    graph_data.append(
        _clickable_vertex_trace(
            go, graph_coordinates, stable_indices, selected_index, adjacent_indices
        )
    )

    cell_highlights = _cell_highlight_data(
        Plotly,
        cell_by_index,
        selected_index,
        adjacent_indices,
    )

    if view == "model":
        data = model_faces + model_edges + cell_highlights
    elif view == "graph":
        # Faces are intentionally omitted so they cannot occlude click targets.
        data = model_edges + graph_data
    else:
        data = model_faces + model_edges + cell_highlights + graph_data

    figure = Plotly.FigureByData(
        data,
        width=950,
        height=620,
        backgroundColor="#f5f7f3",
        xAxis=False,
        yAxis=False,
        zAxis=False,
    )
    if figure is None:
        raise RuntimeError("Plotly.FigureByData could not create the figure.")
    set_scene_bounds(figure, model)
    set_camera(figure, parameters.get("_camera"), [1.4, -1.6, 1.25])
    figure.update_layout(clickmode="event+select")

    if selected_index is None:
        message = "Click a graph vertex or a CellComplex face."
    else:
        message = (
            f"Vertex {selected_index} has {len(adjacent_indices)} directly "
            "adjacent vertices. Click another vertex to inspect it."
        )

    return {
        "parameters": {
            "columns": columns,
            "rows": rows,
            "layers": layers,
            "width": width,
            "length": length,
            "height": height,
        },
        "selection": {
            "selectedIndex": selected_index,
            "adjacentIndices": adjacent_indices,
        },
        "metrics": {
            "cells": len(cells),
            "graphVertices": len(records),
            "graphEdges": len(graph_edges),
            # The current shell already has this metric slot. Here it reports
            # the size of the selected vertex's direct neighbourhood.
            "pathVertices": len(adjacent_indices) if selected_index is not None else None,
            "elapsedMs": round((time.perf_counter() - started) * 1000, 2),
        },
        "plotly": json.loads(figure.to_json()),
        "engine": {
            "name": "TopologicPy",
            "version": _version(),
            "python": platform.python_version(),
        },
        "message": message,
    }


def _latest_click_token(parameters):
    # The current click hook alternates between _startIndex and _endIndex.
    # Prefer the end token because it represents the most recent second click.
    for key in ("_endIndex", "_startIndex"):
        try:
            return int(parameters.get(key))
        except (TypeError, ValueError):
            continue
    return None


def _resolve_clicked_selection(
    parameters,
    stable_indices,
    faces,
    model,
    graph_index_by_cell_id,
    Topology,
    Dictionary,
):
    """Resolve either a graph-vertex click or an exact topological face click."""
    token = _latest_click_token(parameters)
    if token is None:
        return None

    valid_indices = set(stable_indices)
    if token in valid_indices:
        return token
    if token >= 0:
        return None

    # Face IDs are encoded as negative integers because the current Explorer
    # click hook transports one integer field named vertexIndex. The backend,
    # not the browser, performs the face -> cell -> graph-vertex resolution.
    face_id = -token - 1
    face = _face_by_id(faces, face_id, Topology, Dictionary)
    if face is None:
        return None

    incident_cells = Topology.SuperTopologies(
        face, model, topologyType="Cell", silent=True
    ) or []
    candidates = []
    for cell in incident_cells:
        cell_id = _topology_cell_id(cell, Topology, Dictionary)
        graph_index = graph_index_by_cell_id.get(str(cell_id))
        if graph_index in valid_indices:
            candidates.append(graph_index)

    candidates = sorted(set(candidates))
    if not candidates:
        return None

    # An internal face has two incident cells. Select one pseudo-randomly but
    # deterministically so camera/view refreshes do not make selection jump.
    return random.Random(face_id).choice(candidates)


def _assign_cell_ids(cells, Topology):
    """Assign deterministic IDs before TGraph.ByTopology copies dictionaries."""
    for position, cell in enumerate(cells):
        cell_id = f"cell_{position:06d}"
        tagged_cell = Topology.SetDictionary(
            cell, {CELL_ID_KEY: cell_id}, silent=True
        )
        if tagged_cell is not None:
            cells[position] = tagged_cell


def _assign_face_ids(faces, Topology):
    """Give every exact model face a stable ID used by Plotly click payloads."""
    for position, face in enumerate(faces):
        tagged_face = Topology.SetDictionary(
            face, {FACE_ID_KEY: position}, silent=True
        )
        if tagged_face is not None:
            faces[position] = tagged_face


def _graph_indices_by_cell_id(records):
    """Index TGraph vertex records by their inherited cell IDs."""
    result = {}
    for position, record in enumerate(records):
        dictionary = record.get("dictionary") or {}
        cell_id = dictionary.get(CELL_ID_KEY)
        if cell_id is None:
            continue
        result[str(cell_id)] = int(record.get("index", position))
    return result


def _topology_cell_id(cell, Topology, Dictionary):
    dictionary = Topology.Dictionary(cell, silent=True)
    return Dictionary.ValueAtKey(
        dictionary, CELL_ID_KEY, defaultValue=None, silent=True
    )


def _topology_face_id(face, Topology, Dictionary):
    dictionary = Topology.Dictionary(face, silent=True)
    return Dictionary.ValueAtKey(
        dictionary, FACE_ID_KEY, defaultValue=None, silent=True
    )


def _face_by_id(faces, face_id, Topology, Dictionary):
    for face in faces:
        value = _topology_face_id(face, Topology, Dictionary)
        try:
            if int(value) == face_id:
                return face
        except (TypeError, ValueError):
            continue
    return None


def _cells_by_graph_index(cells, graph_index_by_cell_id, Topology, Dictionary):
    """Map graph indices back to cells exclusively through inherited IDs."""
    result = {}
    for cell in cells:
        cell_id = _topology_cell_id(cell, Topology, Dictionary)
        graph_index = graph_index_by_cell_id.get(str(cell_id))
        if graph_index is not None:
            result[graph_index] = cell
    return result


def _clickable_model_face_data(Plotly, faces, Topology, Dictionary):
    """Render one trace per exact face and attach its backend selection token."""
    data = []
    first_face = True
    for face in faces:
        face_id = _topology_face_id(face, Topology, Dictionary)
        try:
            face_id = int(face_id)
        except (TypeError, ValueError):
            continue

        traces = Plotly.DataByTopology(
            face,
            showVertices=False,
            showEdges=False,
            showFaces=True,
            faceColor="#d9f45a",
            faceOpacity=0.2,
            showFaceLegend=first_face,
            faceLegendLabel="CellComplex",
            silent=True,
        ) or []
        token = -(face_id + 1)
        tagged = False
        for trace in traces:
            if str(getattr(trace, "type", "")).lower() != "mesh3d":
                continue
            count = len(getattr(trace, "x", None) or [])
            trace.customdata = [
                {
                    "vertexIndex": token,
                    "faceId": face_id,
                    "sourceType": "face",
                }
                for _ in range(count)
            ]
            trace.hovertemplate = (
                "Face %{customdata.faceId}"
                "<extra>Click to inspect adjacency</extra>"
            )
            tagged = True
        data.extend(traces)
        if tagged:
            first_face = False
    return data


def _tag_cell_face_traces(traces, vertex_index):
    """Keep highlighted cell faces clickable after they cover base faces."""
    for trace in traces:
        if str(getattr(trace, "type", "")).lower() != "mesh3d":
            continue
        count = len(getattr(trace, "x", None) or [])
        trace.customdata = [
            {"vertexIndex": vertex_index, "sourceType": "face"}
            for _ in range(count)
        ]
        trace.hovertemplate = (
            "Cell graph vertex %{customdata.vertexIndex}"
            "<extra>Click to inspect adjacency</extra>"
        )


def _cell_highlight_data(
    Plotly, cell_by_index, selected_index, adjacent_indices
):
    if selected_index is None:
        return []

    data = []
    first_adjacent = True
    for index in adjacent_indices:
        adjacent_cell = cell_by_index.get(index)
        if adjacent_cell is None:
            continue
        traces = Plotly.DataByTopology(
            adjacent_cell,
            showVertices=False,
            showEdges=True,
            edgeWidth=3,
            edgeColor="#c9632d",
            showFaces=True,
            faceColor="#f08c46",
            faceOpacity=0.78,
            showFaceLegend=first_adjacent,
            faceLegendLabel="Adjacent cells",
            silent=True,
        ) or []
        _tag_cell_face_traces(traces, index)
        data.extend(traces)
        first_adjacent = False

    selected_cell = cell_by_index.get(selected_index)
    if selected_cell is not None:
        traces = Plotly.DataByTopology(
            selected_cell,
            showVertices=False,
            showEdges=True,
            edgeWidth=4,
            edgeColor="#195bb8",
            showFaces=True,
            faceColor="#2f7bf6",
            faceOpacity=0.88,
            showFaceLegend=True,
            faceLegendLabel="Selected cell",
            silent=True,
        ) or []
        _tag_cell_face_traces(traces, selected_index)
        data.extend(traces)
    return data


def _clickable_vertex_trace(
    go, coordinates, stable_indices, selected_index, adjacent_indices
):
    adjacent = set(adjacent_indices)
    colors = []
    sizes = []
    for index in stable_indices:
        if index == selected_index:
            colors.append("#2f7bf6")
            sizes.append(20)
        elif index in adjacent:
            colors.append("#f08c46")
            sizes.append(18)
        else:
            colors.append("#173c2b")
            sizes.append(12)

    return go.Scatter3d(
        x=[point[0] for point in coordinates],
        y=[point[1] for point in coordinates],
        z=[point[2] for point in coordinates],
        mode="markers",
        name="Element centroids",
        marker={
            "size": sizes,
            "color": colors,
            "line": {"color": "#ffffff", "width": 1},
        },
        customdata=[{"vertexIndex": index} for index in stable_indices],
        hovertemplate=(
            "Graph vertex %{customdata.vertexIndex}<extra>Click to inspect adjacency</extra>"
        ),
        showlegend=True,
    )
