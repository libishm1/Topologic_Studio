from __future__ import annotations
import platform
import time
import json
from typing import Any

METADATA = {
    "id": "01_spaces-to-graph",
    "title": "From spaces to relationships",
    "category": "Topology basics",
    "description": (
        "Create a cellular CellComplex and derive its adjacency TGraph."
    ),
    "frontend": "spaces-to-graph",
    "code": "model = CellComplex.Prism(\n    width=12, length=9, height=3,\n    uSides=columns, vSides=rows, wSides=layers\n)\ntgraph = TGraph.ByTopology(model, direct=False,\n    viaSharedTopologies=True, ontology=False)\nmodel_data = Plotly.DataByTopology(model, ...)\ngraph_data = Plotly.DataByTGraph(tgraph, ...)\nfigure = Plotly.FigureByData(model_data + graph_data)",

    "parameters": [
        {
            "key": "columns",
            "label": "Columns",
            "type": "integer",
            "control": "slider",
            "min": 2,
            "max": 6,
            "step": 1,
            "default": 3,
        },
        {
            "key": "rows",
            "label": "Rows",
            "type": "integer",
            "control": "slider",
            "min": 2,
            "max": 6,
            "step": 1,
            "default": 3,
        },
        {
            "key": "layers",
            "label": "Layers",
            "type": "integer",
            "control": "slider",
            "min": 2,
            "max": 6,
            "step": 1,
            "default": 3,
        },
        {
            "key": "width",
            "label": "Width",
            "type": "number",
            "control": "slider",
            "min": 2,
            "max": 6,
            "step": 0.5,
            "default": 3,
        },
        {
            "key": "length",
            "label": "Length",
            "type": "number",
            "control": "slider",
            "min": 2,
            "max": 6,
            "step": 0.5,
            "default": 3,
        },
        {
            "key": "height",
            "label": "Height",
            "type": "number",
            "control": "slider",
            "min": 2,
            "max": 6,
            "step": 0.5,
            "default": 3,
        },
        {
            "key": "viaSharedTopologies",
            "label": "Via Shared Topologies",
            "type": "boolean",
            "control": "checkbox",
            "default": False
        },
        {
            "key": "toExteriorTopologies",
            "label": "To Exterior Topologies",
            "type": "boolean",
            "control": "checkbox",
            "default": False
        }

    ],
    "views": ["model", "graph", "combined"],
}

def _version() -> str:
    import topologicpy
    return str(getattr(topologicpy, "__version__", "unknown"))

def execute(parameters: dict[str, Any]) -> dict[str, Any]:
    from topologicpy.CellComplex import CellComplex
    from topologicpy.Plotly import Plotly
    from topologicpy.TGraph import TGraph
    from topologicpy.Topology import Topology
    from explorer.plotly_scene import set_camera, set_scene_bounds

    columns = max(2, min(6, int(parameters.get("columns", 3))))
    rows = max(2, min(6, int(parameters.get("rows", 3))))
    layers = max(2, min(6, int(parameters.get("layers", 3))))
    width = max(2.0, min(6.0, float(parameters.get("width", 3))))
    length = max(2.0, min(6.0, float(parameters.get("length", 3))))
    height = max(2.0, min(6.0, float(parameters.get("height", 3))))
    viaSharedTopologies = bool(parameters.get("viaSharedTopologies", False))
    direct = not viaSharedTopologies
    toExteriorTopologies = bool(parameters.get("toExteriorTopologies", False))
    view = str(parameters.get("_view", "combined")).lower()
    started = time.perf_counter()
    model = CellComplex.Prism(width=width, length=length, height=height,
        uSides=columns, vSides=rows, wSides=layers, placement="center", tolerance=0.0001)
    if model is None:
        raise RuntimeError("CellComplex.Prism returned None.")
    tgraph = TGraph.ByTopology(
        model, direct=direct, viaSharedTopologies=viaSharedTopologies, toExteriorTopologies=toExteriorTopologies, ontology=False, silent=True
    )
    if tgraph is None:
        raise RuntimeError("TGraph.ByTopology returned None.")
    cells = Topology.Cells(model) or []
    graph_vertices = TGraph.Vertices(tgraph, copy=False, asTopologic=False) or []
    graph_edges = TGraph.Edges(tgraph, asTopologic=False) or []
    model_data = Plotly.DataByTopology(
        model, showVertices=False, showEdges=True, edgeWidth=1,
        edgeColor="#7d897f", showFaces=True, faceColor="#d9f45a",
        faceOpacity=0.2, showFaceLegend=True, faceLegendLabel="CellComplex",
        silent=True,
    ) or []
    graph_data = Plotly.DataByTGraph( tgraph,
                                     showVertices=True,
                                     vertexSize=12,
                                     vertexColor="#173c2b",
                                     vertexBorderColor="#ffffff",
                                     vertexBorderWidth=1,
                                     showVertexLegend=True,
                                     vertexLegendLabel="Element centroids",
                                     showEdges=True,
                                     edgeWidth=3,
                                     edgeColor="#557164",
                                     showEdgeLegend=True,
                                     edgeLegendLabel="Adjacency",
                                     silent=True,
    ) or []
    if view == "model":
        data = model_data
    elif view == "graph":
        data = graph_data
    else:
        data = model_data + graph_data
    figure = Plotly.FigureByData(
        data, width=950, height=620, backgroundColor="#f5f7f3",
        xAxis=False, yAxis=False, zAxis=False,
    )
    if figure is None:
        raise RuntimeError("Plotly.FigureByData could not create the figure.")
    set_scene_bounds(figure, model)
    set_camera(figure, parameters.get("_camera"), [1.4, -1.6, 1.25])
    return {
        "parameters": {"columns": columns,
                       "rows": rows,
                       "layers": layers,
                       "width": width,
                       "length": length,
                       "height": height,
                       "viaSharedTopologies": viaSharedTopologies,
                       "toExteriorTopologies": toExteriorTopologies
                       },
        "metrics": {"cells": len(cells), "graphVertices": len(graph_vertices), "graphEdges": len(graph_edges),
            "elapsedMs": round((time.perf_counter() - started) * 1000, 2)},
        "plotly": json.loads(figure.to_json()),
        "engine": {"name": "TopologicPy", "version": _version(), "python": platform.python_version()},
        "message": "CellComplex and adjacency TGraph computed locally.",
    }
