from __future__ import annotations

import math
from typing import Any


def clean_camera(value: Any) -> dict[str, Any] | None:
    """Return a small, JSON-safe Plotly camera dictionary or ``None``."""
    if not isinstance(value, dict):
        return None
    camera: dict[str, Any] = {}
    for name in ("eye", "center", "up"):
        vector = value.get(name)
        if not isinstance(vector, dict):
            continue
        cleaned = {}
        for axis in ("x", "y", "z"):
            try:
                number = float(vector[axis])
            except (KeyError, TypeError, ValueError):
                break
            if not math.isfinite(number):
                break
            cleaned[axis] = number
        if len(cleaned) == 3:
            camera[name] = cleaned
    projection = value.get("projection")
    if isinstance(projection, dict):
        projection_type = str(projection.get("type", "")).lower()
        if projection_type in {"perspective", "orthographic"}:
            camera["projection"] = {"type": projection_type}
    return camera or None


def set_camera(figure, value: Any, default_eye: list[float]):
    """Apply a browser camera, falling back to TopologicPy's camera helper."""
    from topologicpy.Plotly import Plotly

    camera = clean_camera(value)
    if camera:
        figure.update_layout(scene_camera=camera)
    else:
        Plotly.SetCamera(
            figure,
            camera=default_eye,
            center=[0, 0, 0],
            up=[0, 0, 1],
            projection="perspective",
        )
    return figure

def set_scene_bounds(figure, topology, padding: float = 0.08):
    from topologicpy.Topology import Topology
    from topologicpy.Vertex import Vertex

    vertices = Topology.Vertices(topology) or []
    coordinates = [
        Vertex.Coordinates(vertex, mantissa=6)
        for vertex in vertices
    ]

    if not coordinates:
        return figure

    ranges = []
    for axis in range(3):
        values = [float(point[axis]) for point in coordinates]
        minimum = min(values)
        maximum = max(values)
        span = maximum - minimum

        # Protect flat or nearly flat models.
        margin = span * padding if span > 0.0001 else 1.0
        ranges.append([minimum - margin, maximum + margin])

    figure.update_layout(
        scene=dict(
            xaxis=dict(
                visible=False,
                autorange=False,
                range=ranges[0],
            ),
            yaxis=dict(
                visible=False,
                autorange=False,
                range=ranges[1],
            ),
            zaxis=dict(
                visible=False,
                autorange=False,
                range=ranges[2],
            ),
            aspectmode="data",
        )
    )
    return figure