"""Local TopologicPy Explorer runtime."""
__version__ = "0.5.0"
