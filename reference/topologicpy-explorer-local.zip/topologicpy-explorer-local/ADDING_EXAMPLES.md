# Adding an Explorer example

Each example is an independent Python module in `explorer/examples`. The server discovers valid modules automatically when it starts.

## 1. Create the backend module

Copy `explorer/examples/_template.py.txt` to a new `.py` file, such as:

```text
explorer/examples/disjoint_routes.py
```

Give it a unique `METADATA["id"]` and implement `execute(parameters)`.

The function must return JSON-compatible data containing:

- `parameters`: validated values used by the computation
- `metrics`: results displayed by the interface
- `plotly`: a serialized Plotly figure built from TopologicPy data
- `engine`: TopologicPy and Python version information
- `message`: a short successful-result description

## 2. Declare controls in metadata

The interface generates controls from `METADATA["parameters"]`:

```json
[
  {"key": "count", "label": "Count", "type": "integer", "control": "slider",
   "min": 1, "max": 20, "step": 1, "default": 5},
  {"key": "scale", "label": "Scale", "type": "number", "control": "number",
   "min": 0.1, "max": 10, "step": 0.1, "default": 1},
  {"key": "enabled", "label": "Enabled", "type": "boolean",
   "control": "checkbox", "default": true}
]
```

Supported controls are `slider`, `number`, and `checkbox`. Values are sent as integers, floats, and booleans respectively. The Python example must still validate and clamp them.

## 3. Return the real TopologicPy Plotly figure

```python
model_data = Plotly.DataByTopology(model, faceColor="#d9f45a", ...)
graph_data = Plotly.DataByTGraph(tgraph, edgeColor="#557164", ...)
figure = Plotly.FigureByData(model_data + graph_data)
set_camera(figure, parameters.get("_camera"), [1.4, -1.6, 1.25])

return {
    "plotly": json.loads(figure.to_json()),
    # parameters, metrics, engine and message...
}
```

## 4. Keep execution safe

- Validate and clamp every user-controlled parameter.
- Do not evaluate Python source received from the browser.
- Do not accept arbitrary local file paths without an explicit file-selection workflow.
- Return concise errors; do not expose secrets or environment variables.

## 5. Restart and verify

Restart `server.py`, then visit:

```text
http://127.0.0.1:8765/api/examples
```

Your module metadata should appear in the returned list.
It will also receive an active example card at the bottom of the page automatically.
