@echo off
title TopologicPy Explorer
python server.py
if errorlevel 1 (
  echo.
  echo The Explorer could not start. Activate the Conda environment containing TopologicPy and try again.
  pause
)
