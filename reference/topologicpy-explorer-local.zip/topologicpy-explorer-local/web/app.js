const $=id=>document.getElementById(id);
let examples=[],example=null,parameters={},view="combined",runTimer=null,startIndex=null,endIndex=null,currentCamera=null;

async function loadExamples(){
  examples=await fetch("/api/examples").then(r=>r.json());
  if(!examples.length)throw Error("No examples are installed.");
  const select=$("exampleSelect");select.replaceChildren();
  for(const item of examples){const option=document.createElement("option");option.value=item.id;option.textContent=item.title;select.append(option)}
  renderExampleCards();
  select.addEventListener("change",()=>selectExample(select.value,true));
  selectExample(examples[0].id,false);
}
function selectExample(id,runNow){
  const next=examples.find(item=>item.id===id);if(!next)return;
  if(example?.id!==next.id)currentCamera=null;example=next;$("exampleSelect").value=id;
  startIndex=endIndex=null;view=example.views?.includes("combined")?"combined":example.views?.[0]||"combined";
  $("exampleTitle").textContent=example.title;$("exampleCategory").textContent=example.category.toUpperCase();$("exampleDescription").textContent=example.description;$("codeExample").textContent=example.code||"";
  document.querySelectorAll(".tabs button").forEach(b=>{b.hidden=!(example.views||[]).includes(b.dataset.mode);b.classList.toggle("active",b.dataset.mode===view)});
  renderControls(example.parameters||[]);updateInteractionHelp();$("pathMetric").hidden=example.interaction!=="vertex-pair";
  document.querySelectorAll(".example-card").forEach(card=>{const active=card.dataset.example===id;card.classList.toggle("active",active);card.setAttribute("aria-pressed",String(active))});
  if(runNow)run();
}
function renderExampleCards(){
  const host=$("exampleCards");host.replaceChildren();
  examples.forEach((item,index)=>{const card=document.createElement("button");card.type="button";card.className="example-card";card.dataset.example=item.id;card.setAttribute("aria-pressed","false");card.innerHTML=`<span>${String(index+1).padStart(2,"0")}</span><b>${escapeHtml(item.title)}</b><p>${escapeHtml(item.description)}</p>`;card.onclick=()=>{selectExample(item.id,true);document.querySelector(".lab").scrollIntoView({behavior:"smooth",block:"start"})};host.append(card)});
}
function escapeHtml(value){const node=document.createElement("span");node.textContent=String(value??"");return node.innerHTML}
function renderControls(definitions){
  const host=$("parameterControls");host.replaceChildren();parameters={};
  for(const def of definitions){parameters[def.key]=def.default;const label=document.createElement("label");label.className=def.control==="checkbox"?"boolean-control":"";
    if(def.control==="checkbox"){const input=document.createElement("input");input.type="checkbox";input.checked=Boolean(def.default);input.onchange=()=>{parameters[def.key]=input.checked;resetSelection();scheduleRun()};const title=document.createElement("span");title.textContent=def.label;label.append(input,title)}
    else{const heading=document.createElement("span"),title=document.createElement("span"),value=document.createElement("b");title.textContent=def.label;value.textContent=String(def.default);heading.append(title,value);const input=document.createElement("input");input.type=def.control==="slider"?"range":"number";for(const key of ["min","max","step"])if(def[key]!==undefined)input[key]=def[key];input.value=def.default;const update=()=>{const raw=Number(input.value),typed=def.type==="integer"?Math.round(raw):raw;parameters[def.key]=typed;value.textContent=String(typed)};input.oninput=()=>{update();if(def.control==="slider"){resetSelection();scheduleRun()}};input.onchange=()=>{update();resetSelection();scheduleRun()};label.append(heading,input)}
    host.append(label);
  }
}
function resetSelection(){startIndex=endIndex=null;updateInteractionHelp()}
function updateInteractionHelp(message){
  const help=$("interactionHelp");if(example?.interaction!=="vertex-pair"){help.hidden=true;return}help.hidden=false;
  help.textContent=message||(startIndex===null?"Click a graph vertex to set the start.":endIndex===null?`Start: vertex ${startIndex}. Click a destination.`:`Route: vertex ${startIndex} → vertex ${endIndex}. Click another vertex to start again.`);
}
async function status(){try{const d=await fetch("/api/status").then(r=>r.json()),e=$("engine");if(!d.ok)throw Error();e.className="engine online";e.querySelector("b").textContent=`TopologicPy ${d.version}`;e.querySelector("small").textContent=`Python ${d.python} · local`;await run()}catch{$("engine").className="engine offline";$("engine").querySelector("b").textContent="TopologicPy unavailable";$("engine").querySelector("small").textContent="Activate the correct environment";$("statusText").textContent="Waiting for TopologicPy"}}
function scheduleRun(){clearTimeout(runTimer);runTimer=setTimeout(run,260)}
async function run(){
  if(!example)return;const b=$("run"),err=$("error"),plot=$("plotlyViewport");b.disabled=true;b.textContent="Computing locally…";err.hidden=true;$("statusText").textContent="Building Plotly data locally…";
  try{const payload={...parameters,_view:view,_startIndex:startIndex,_endIndex:endIndex,_camera:currentCamera},r=await fetch("/api/execute",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({example:example.id,parameters:payload})}),d=await r.json();if(!r.ok)throw Error(d.error||"Execution failed");const result=d.result,m=result.metrics,fig=result.plotly;fig.layout={...(fig.layout||{}),autosize:true,uirevision:example.id};fig.layout.scene={...(fig.layout.scene||{}),uirevision:example.id};if(currentCamera)fig.layout.scene.camera=currentCamera;delete fig.layout.width;delete fig.layout.height;await Plotly.react(plot,fig.data,fig.layout,{responsive:true,displaylogo:false,scrollZoom:true,modeBarButtonsToRemove:["sendDataToCloud"]});
    if(typeof plot.removeAllListeners==="function"){plot.removeAllListeners("plotly_click");plot.removeAllListeners("plotly_relayout")}
    plot.on("plotly_relayout",()=>{currentCamera=cameraFromPlot(plot)||currentCamera});
    if(example.interaction==="vertex-pair")plot.on("plotly_click",event=>{const index=event?.points?.[0]?.customdata?.vertexIndex;if(!Number.isInteger(index))return;if(startIndex===null||endIndex!==null){startIndex=index;endIndex=null}else if(index!==startIndex){endIndex=index}updateInteractionHelp();run()});
    $("cells").textContent=m.cells;$("nodes").textContent=m.graphVertices;$("edges").textContent=m.graphEdges;$("runtime").textContent=m.elapsedMs;
    $("pathVertices").textContent=m.pathVertices??"—";$("statusText").textContent=`Plotly.FigureByData · TopologicPy ${result.engine.version}`;if(result.message)updateInteractionHelp(result.message);
  }catch(e){err.textContent=e.message;err.hidden=false;$("statusText").textContent="Execution failed"}finally{b.disabled=false;b.textContent="▶ Run with local TopologicPy"}
}
function cameraFromPlot(plot){
  const source=plot?._fullLayout?.scene?.camera;if(!source)return null;const vector=name=>{const v=source[name];return v&&[v.x,v.y,v.z].every(Number.isFinite)?{x:v.x,y:v.y,z:v.z}:null};
  const camera={};for(const name of ["eye","center","up"]){const v=vector(name);if(v)camera[name]=v}const type=source.projection?.type;if(type==="perspective"||type==="orthographic")camera.projection={type};return Object.keys(camera).length?camera:null;
}
function setView(name){view=name;document.querySelectorAll(".tabs button").forEach(b=>b.classList.toggle("active",b.dataset.mode===name));run()}
document.querySelectorAll(".tabs button").forEach(b=>b.onclick=()=>setView(b.dataset.mode));$("run").onclick=run;
loadExamples().then(status).catch(e=>{$("error").textContent=e.message;$("error").hidden=false});
